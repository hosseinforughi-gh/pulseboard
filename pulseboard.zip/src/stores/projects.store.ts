import { getProjects, type Project } from "@/services/projects.services";
import { create } from "zustand";

type ProjectsState = {
  projects: Project[];
  isLoading: boolean;
  error: string | null;

  fetchProjects: () => Promise<void>;
};

export const useProjectsStore = create<ProjectsState>((set) => ({
  projects: [],
  isLoading: false,
  error: null,

  fetchProjects: async () => {
    set({ isLoading: true, error: null });
    try {
      const projects = await getProjects();
      set({ projects });
    } catch (err) {
      set({ error: "Failed to load projects" });
    } finally {
      set({ isLoading: false });
    }
  },
}));
