import { useEffect } from "react";
import { useProjectsStore } from "@/stores/projects.store";

export default function ProjectsPage() {
  const { projects, isLoading, error, fetchProjects } = useProjectsStore();

  useEffect(() => {
    fetchProjects();
  }, [fetchProjects]);

  if (isLoading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div className="space-y-2">
      {projects.map((p) => (
        <div key={p.id} className="rounded-xl border p-3">
          {p.title}
        </div>
      ))}
    </div>
  );
}
